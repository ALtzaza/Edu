
import forwardserver from "./websockets/forwardServer.js";

forwardserver.listen(3003)