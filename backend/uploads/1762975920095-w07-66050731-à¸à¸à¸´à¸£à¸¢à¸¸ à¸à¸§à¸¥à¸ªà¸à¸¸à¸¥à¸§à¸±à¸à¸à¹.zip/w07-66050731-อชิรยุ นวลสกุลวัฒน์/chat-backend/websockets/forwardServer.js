import { createServer } from 'node:http'
import { WebSocketServer } from 'ws'

//create http server
const forwardserver = createServer()

//create ws server
const wss = new WebSocketServer({ server: forwardserver, path: "/" })

//coding...
//listen events
wss.on('listening', () => { 
    console.log(`[forwardServer,n:${wss.clients.size}]- listenig`)
})
//connection events
wss.on('connection', (ws) => {
    //new connection 
    console.log(`[forwardServer,n:${wss.clients.size}]- new connection`)
    //message events
    ws.on('message',(message) => {
        const messageString = message.toString()
        console.log(`[forwardServer,n:${wss.clients.size}]- recived: ${messageString}`)
        wss.clients.forEach((client) => {
            client.send(messageString)
        })
        console.log(`[forwardServer,n:${wss.clients.size}]- sent: "${messageString}", for ${wss.clients.size}`,
            wss.clients.size === 1 ? 'time' : 'times'
        )
    })

    //close events
    ws.on('close', () => {
        console.log(`[forwardServer,n:${wss.clients.size}]- closed`)
    })

})

export default forwardserver