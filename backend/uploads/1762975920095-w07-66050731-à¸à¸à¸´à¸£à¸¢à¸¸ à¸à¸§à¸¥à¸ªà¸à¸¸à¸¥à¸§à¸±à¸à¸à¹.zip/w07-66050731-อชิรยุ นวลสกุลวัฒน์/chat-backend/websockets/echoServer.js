import { createServer } from 'node:http'
import { WebSocketServer } from 'ws'

//create http server
const echoserver = createServer()

// ( create ws server
const wss = new WebSocketServer({ server: echoserver, path: '/' })


//listen events
wss.on('listening', () => {
    console.log(`[echoServer,n:${wss.clients.size}]- listenig`)
})
//connection events
wss.on('connection', (ws) => {
    console.log(`[echoServer,n:${wss.clients.size}]- new connection`)
    ws.on('message', (message) => {
        console.log(message) //byte code 
        const messageString = message.toString()
        console.log(`[echoServer,n:${wss.clients.size}]- recived: ${messageString}`)
        ws.send(messageString)
        console.log(`[echoServer,n:${wss.clients.size}]- sent: ${messageString}`)
    })

    ws.on('close', () => {
        console.log(`[echoServer,n:${wss.clients.size}]- connection closed`)
    })
})


export default echoserver

