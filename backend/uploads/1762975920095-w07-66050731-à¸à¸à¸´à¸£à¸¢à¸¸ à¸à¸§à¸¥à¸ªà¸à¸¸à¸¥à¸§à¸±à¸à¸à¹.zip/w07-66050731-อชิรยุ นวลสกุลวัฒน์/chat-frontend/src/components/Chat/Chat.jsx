import { useState, useEffect, useRef } from 'react'
import useWebSocket from 'react-use-websocket'
import './Chat.css'

const defaultName = ''
const defaultMessage = ''
const dummyMessages = [
  // { name: 'สมชาย', message: `สวัสดี เราสมชายนะ` },
  // { name: 'Alice', message: `Hi, I'm Alice` },
  // { name: 'Zoe', message: `How are you, today?` },
  // { name: 'สมชาย', message: `ฝุ่นเยอะม๊าก แต่ยังรอดชีวิตอยู่` },
  // { name: 'Zoe', message: `How about front-end and back-end?` },
  // { name: 'Alice', message: `I like both ^_^` },
  // { name: 'สมชาย', message: `เราไม่ชอบทั้งคู่เลยอะ... 555` },
]

function Chat() {
  const [name, setName] = useState('')
  const [message, setMessage] = useState('')
  const [messages, setMessages] = useState([])

  const{sendMessage, lastMessage} = useWebSocket('ws://localhost:3003')

  const displayRef = useRef()
  const messageRef = useRef()
//websocket : input from forwardServer
  useEffect(() => {
    if(lastMessage === null) return
    const newMessage = JSON.parse(lastMessage.data)
    setMessages([...messages, newMessage])
  }, [lastMessage] )

  useEffect(() => {
    setName(defaultName)
    setMessage(defaultMessage)
    setMessages(dummyMessages)
    messageRef.current.focus()
  }, [])

  useEffect(() => {
    displayRef.current.scrollTop = displayRef.current.scrollHeight
  }, [messages])

  const sendClick = () => {
    if (name.trim() === '') return console.error('Error: empty name')
    if (message.trim() === '') return console.error('Error: empty message')
    const newMessage = {
      // id: messages.reduce((max, msg) => Math.max(max, msg.id), 0) + 1,
      name: name.trim(),
      message: message.trim(),
    }
    //websocket : set to forwardServer
    sendMessage(JSON.stringify(newMessage))
    setMessage('')
    messageRef.current.focus()
  }

  const nameMatch = { color: 'blue' }

  return (
    <div className='chat-container'>
      {/* Header */}
      <h2>
        <big>&#128536;</big>&nbsp;SELF CHATTING&nbsp;<big>&#128536;</big>
      </h2>

      {/* History */}
      <div className='chat-display' ref={displayRef}>
        {messages.map((msg) => (
          <div key={Math.random()}>
            <b style={msg.name === name.trim() ? nameMatch : {}}>{msg.name}</b>
            :&nbsp;
            <span style={msg.name === name.trim() ? nameMatch : {}}>
              {msg.message}
            </span>
          </div>
        ))}
      </div>

      {/* Input */}
      <div className='chat-input'>
        <input
          className='name'
          placeholder='Your name'
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendClick(e)}
        ></input>
        <input
          className='message'
          placeholder='Your message...'
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendClick(e)}
          ref={messageRef}
        ></input>
        <button className='send' onClick={() => sendClick()}>
          Send
        </button>
      </div>
    </div>
  )
}

export default Chat
