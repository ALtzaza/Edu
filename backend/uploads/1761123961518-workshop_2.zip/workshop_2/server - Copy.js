const express = require('express');
const app = express();
app.use(express.json());

let employee= [
 { id: 1, name: 'Antony Thompson', email: 'antony@example.com', age: 20},
{id: 2, name: 'Bob Davis', email: 'bob@example.com', age: 21 }
];


app.get('/api/employe', (req, res) => {
    res.status(200).json(employee);
});



app.post('/api/employee', (req, res) => {
    const nextId = employee.length + 1;
    const {name, email, age} = req.body;
    const newEmployee = {
        id:  nextId,
        name,
        email,
        age
    }
    employee.push(newEmployee);
    res.status(201).json(newEmployee);
})



app.put('/api/employee/:eid', (req, res) => {
  const { eid } = req.params;
  const empIndex = employee.findIndex(emp => emp.id === parseInt(eid));

  if (empIndex === -1) return res.status(404).json({ msg: 'Employee not found' });

  employee[empIndex] = { ...employee[empIndex], ...req.body };
  res.status(201).json(employee[empIndex]);
});

app.put('/api/employee/email/:email', (req, res) => {
  const { email } = req.params;
   const empIndex = employee.findIndex(emp => emp.email === email);
    if (empIndex === -1) 
        return res.status(404).json({ msg: 'Employee not found' });
    employee[empIndex] = { ...employee[empIndex], ...req.body };  
    res.status(201).json(employee[empIndex]);
});



app.delete('/api/employee/:eid', (req, res) => {
  const { eid } = req.params;
  const empIndex = employee.findIndex(emp => emp.id === parseInt(eid));
    if (empIndex === -1) 
        return res.status(404).json({ msg: 'Employee not found' });
    const deletedEmployee = employee.splice(empIndex, 1);
    employee = employee.map((emp, index) => ({ ...emp, id: index + 1 }));
    res.status(200).json(deletedEmployee[0]);
});

app.delete('/api/employee/email/:email', (req, res) => {
  const { email } = req.params;
  const empIndex = employee.findIndex(emp => emp.email === email);
  if (empIndex === -1) 
      return res.status(404).json({ msg: 'Employee not found' });
  const deletedEmployee = employee.splice(empIndex, 1);
  employee = employee.map((emp, index) => ({ ...emp, id: index + 1 }));

  res.status(200).json(deletedEmployee[0]);
});


app.listen(3000, () => {
    console.log('API Server is running on port 3000')
    }
);